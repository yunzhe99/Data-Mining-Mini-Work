# 文件结构说明

- data_check.txt -> 验证的数据 代码要调用
- data_study.txt -> 训练的数据 代码要调用
- KNN_classification.py -> 代码 可以直接运行
- 方法简要说明.pdf -> 方法简要说明
- 运行结果截图.png -> 运行结果截图